<?php

/**
 * Created by PhpStorm.
 * User: Yuchen Yao
 * Date: 6/04/2019
 * Time: 8:38 PM
 */

/* @var $this \yii\web\View */
?>
You have rent a car successfully
