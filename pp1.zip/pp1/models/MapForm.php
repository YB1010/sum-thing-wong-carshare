<?php
/**
 * Created by PhpStorm.
 * User: Yuchen Yao
 * Date: 2/04/2019
 * Time: 11:54 AM
 */

namespace app\models;


class MapForm
{
    function pendingTime(){

    }

}