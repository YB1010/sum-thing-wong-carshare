<?php

return[
      'components' => [
          'assetManager' => [
              'bundles' => [
                  'dosamigos\google\maps\MapAsset' => [
                      'options' => [
                          'key' => 'AIzaSyCJfFLygQCdKq_IfW63CFJtb0Vw6bMEMzY',
                          'language' => 'id',
                          'version' => '3.1.18'
                      ]
                  ]
              ]
         ],
      ],

];